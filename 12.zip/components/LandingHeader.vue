<template>
  <div
    class="
  h-12  justify-between items-center px-4 hidden md:flex"
  >
    <div class="h-full flex items-stretch">
      <nuxt-link to="" class="px-5"><logo class="h-full"/></nuxt-link>
    </div>
    <div class="h-full flex items-stretch">
      <nuxt-link to="" class="px-5 flex items-center">پلن ها</nuxt-link>
      <nuxt-link to="" class="px-5 flex items-center">ارزیابی مهارت ها</nuxt-link>
      <nuxt-link to="" class="px-5 flex items-center">آموختن طراحی</nuxt-link>
    </div>
    <div class="h-full flex items-stretch">
      <nuxt-link to="login" class="px-5 flex items-center">ورود</nuxt-link>
      <nuxt-link to="signup" class="px-5 flex items-center"
        ><span class="rounded-lg bg-black text-white px-5 py-3">ثبت نام</span></nuxt-link
      >
    </div>
  </div>
</template>
