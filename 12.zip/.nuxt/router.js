import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _130423ec = () => interopDefault(import('..\\pages\\dashboard\\index.vue' /* webpackChunkName: "pages/dashboard/index" */))
const _20a2b2f7 = () => interopDefault(import('..\\pages\\login\\index.vue' /* webpackChunkName: "pages/login/index" */))
const _4fd99b08 = () => interopDefault(import('..\\pages\\signup\\index.vue' /* webpackChunkName: "pages/signup/index" */))
const _5442975c = () => interopDefault(import('..\\pages\\dashboard\\arcade\\index.vue' /* webpackChunkName: "pages/dashboard/arcade/index" */))
const _074d1e20 = () => interopDefault(import('..\\pages\\dashboard\\courses\\index.vue' /* webpackChunkName: "pages/dashboard/courses/index" */))
const _048d010b = () => interopDefault(import('..\\pages\\dashboard\\leaderboard\\index.vue' /* webpackChunkName: "pages/dashboard/leaderboard/index" */))
const _56cbb641 = () => interopDefault(import('..\\pages\\dashboard\\saved\\index.vue' /* webpackChunkName: "pages/dashboard/saved/index" */))
const _524f29aa = () => interopDefault(import('..\\pages\\dashboard\\courses\\_course\\index.vue' /* webpackChunkName: "pages/dashboard/courses/_course/index" */))
const _1fdf3b0d = () => interopDefault(import('..\\pages\\lessons\\_id.vue' /* webpackChunkName: "pages/lessons/_id" */))
const _44dfafd8 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/dashboard",
    component: _130423ec,
    name: "dashboard"
  }, {
    path: "/login",
    component: _20a2b2f7,
    name: "login"
  }, {
    path: "/signup",
    component: _4fd99b08,
    name: "signup"
  }, {
    path: "/dashboard/arcade",
    component: _5442975c,
    name: "dashboard-arcade"
  }, {
    path: "/dashboard/courses",
    component: _074d1e20,
    name: "dashboard-courses"
  }, {
    path: "/dashboard/leaderboard",
    component: _048d010b,
    name: "dashboard-leaderboard"
  }, {
    path: "/dashboard/saved",
    component: _56cbb641,
    name: "dashboard-saved"
  }, {
    path: "/dashboard/courses/:course",
    component: _524f29aa,
    name: "dashboard-courses-course"
  }, {
    path: "/lessons/:id?",
    component: _1fdf3b0d,
    name: "lessons-id"
  }, {
    path: "/",
    component: _44dfafd8,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
