import Vue from 'vue'
import VueEllipseProgress from 'vue-ellipse-progress'

Vue.use(VueEllipseProgress)
