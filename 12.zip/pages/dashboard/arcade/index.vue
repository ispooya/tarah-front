<template> </template>
<script>
  export default { layout: 'dashboard' }
</script>
